package JavaDB_001;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;



public class Work extends JFrame{
    JButton button ;
    JLabel label;
    
    public Work(){
    button = new JButton("Browse");
    button.setBounds(0,0,100,40);
    label = new JLabel();
    label.setBounds(0,40,670,250);
    add(button);
    add(label);
    
    button.addActionListener(new ActionListener() {

        public void actionPerformed(ActionEvent e) {
        
          JFileChooser file = new JFileChooser();
          file.setCurrentDirectory(new File(System.getProperty("user.home")));
          FileNameExtensionFilter filter = new FileNameExtensionFilter("*.Images", "jpg","gif","png");
          file.addChoosableFileFilter(filter);
          int result = file.showSaveDialog(null);
          if(result == JFileChooser.APPROVE_OPTION){
              File selectedFile = file.getSelectedFile();
              String path = selectedFile.getAbsolutePath();
              label.setIcon(ResizeFrame(path));
          }


          else if(result == JFileChooser.CANCEL_OPTION){
              System.out.println("No File Select");
          }
        }
    });
    
    setLayout(null);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLocationRelativeTo(null);
    setSize(0,80);
    setVisible(true);
    System.out.println(System.getProperty("user.dir"));
    }

    public ImageIcon ResizeFrame(String ImagePath){
        ImageIcon MyImage = new ImageIcon(ImagePath);
        Image img = MyImage.getImage();
        label.setSize(img.getWidth(rootPane), img.getHeight(rootPane));
        setSize(img.getWidth(rootPane), img.getHeight(rootPane));
        ImageIcon image = new ImageIcon(img);
        return image;
    }
    
    public static void main(String[] args){
        new Work();
    }
   }